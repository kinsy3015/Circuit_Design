#ifndef __SFLASH_SST25PF040__
#define __SFLASH_SST25PF040__

#include <avr/io.h>

//#define SST25PF040_ID					0x6E
#define SST25PF040_ID					0x86	//fake... 0x86 = SST25WF080B ID

#define SST25PF040_CMD_WREN				0x06
#define SST25PF040_CMD_WRDI				0x04
#define SST25PF040_CMD_READID			0xAB
#define SST25PF040_CMD_READ_JEDECID		0x9F
#define SST25PF040_CMD_PAGEPGM			0x02
#define SST25PF040_CMD_READ				0x03
#define SST25PF040_CMD_ERASE_SECTOR		0x20	// or 0xD7
#define SST25PF040_CMD_READWRSR			0x01
#define SST25PF040_CMD_READRDSR			0x05

#define SST25PF040_SECTOR_SIZEBYTE		4096


extern uint32_t DRV_SFlash_ReadID(uint8_t *);
extern uint32_t DRV_SFlash_Read_JEDECID(uint8_t *);

extern uint32_t DRV_SFlash_Write(uint32_t, uint8_t *, uint32_t);
extern uint32_t DRV_SFlash_Read(uint32_t, uint8_t *, uint32_t);

extern uint32_t DRV_SFlash_EraseAddr(uint32_t, uint32_t);

#endif		/* End of __SFLASH_SST25PF040__ */
