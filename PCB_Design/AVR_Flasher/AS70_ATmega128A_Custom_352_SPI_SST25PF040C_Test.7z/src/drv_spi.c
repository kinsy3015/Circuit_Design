/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */
#include <asf.h>
#include <stdio.h>
#include <ioport.h>
#include <util/delay.h>

#include "drv_spi.h"




void DRV_SPI_Init(uint8_t flag)
{
	/* ATmega128A doesn't need this */
	//sysclk_enable_peripheral_clock(&SPCR);

	/* BE SURE TO SET Output/Input definition of SPI pin! */
	if(flag == 1)
	{
		DDRB = 0x1 | 0x02 | 0x04;
	}

	/* MSB Order */
	SPCR = (0 << DORD);

	/* Master/Slave Mode */
	SPCR |= (flag << MSTR);

	/* SCK Polarity */
	SPCR |= (1 << CPOL);

	/* SCK Phase */
	SPCR |= (1 << CPHA);

	/* SCK Frequency */
	SPCR |= (0 << SPR1) | (1 << SPR0);

	SPSR |= (0 << SPI2X);

	/* Enable SPI */
	SPCR |= (1 << SPE);
}




void DRV_SPI_CtrlSS(uint8_t flag)
{
	if(flag == 1)
		PORT_SPI_SS.PORTDATA |= PIN_SPI_SS;
		//PORTB |= PIN_SPI_SS;
	else
		PORT_SPI_SS.PORTDATA &= ~PIN_SPI_SS;
		//PORTB &= ~PIN_SPI_SS;
}




uint32_t DRV_SPI_Send(uint8_t *pbuf, uint32_t size)
{
	uint32_t time_out;
	uint16_t count;


	for(count = 0; count < size; count++)
	{
		time_out = 100000;

		SPDR = pbuf[count];

		while(time_out > 0)
		{
			if(SPSR & (1 << SPIF))	
				break;

			time_out--;
		}

		if(time_out == 0)
		{
			return 1;
		}
	}


	return 0;
}



uint32_t DRV_SPI_Recv(uint8_t *pbuf, uint32_t size)
{
	uint32_t time_out;

    while (size > 0)
	{
		time_out = 100000;

		SPDR = 0xFF;

		while(SPSR & (1 << SPIF) == 0);

		while(time_out)
		{
			if(SPSR & (1 << SPIF))
			{
				*pbuf++ = SPDR;
				size--;
				
				break;
			}

			time_out--;
			
			if(time_out == 0)
			{
				//printf("DRV_SPI_Recv Error\r\n");
				return 1;
			}
		}
    }


	return 0;	
}




uint32_t DRV_SPI_Transceive(uint8_t *ptxbuf, uint32_t tx_size, uint8_t *prxbuf, uint32_t rx_size)
{
	uint16_t count;


	for(count = 0; count < tx_size; count++)
	{
		SPDR = ptxbuf[count];

		while((SPSR & (1 << SPIF)) == 0);

		prxbuf[count] = SPDR;
	}


	return 0;
}
