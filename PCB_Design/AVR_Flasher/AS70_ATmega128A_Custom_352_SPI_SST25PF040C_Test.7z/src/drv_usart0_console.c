#include "asf.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <avr/interrupt.h>
#include <util/delay.h>


#define FOSC							BOARD_EXTERNAL_CLK		/* FOSC = XTAL pin frequency */


static void uart0_tx(char c, FILE *stream);
static void uart0_rx(FILE *stream);

/* When you use ANCI-C key input API... */
static FILE mystdio = FDEV_SETUP_STREAM(uart0_tx, uart0_rx, _FDEV_SETUP_RW);

/* When you DON'T use ANCI-C key input API... */
//static FILE mystdio = FDEV_SETUP_STREAM(uart0_tx, NULL, _FDEV_SETUP_WRITE);


/* CAUTION :
*           unsigned int : 16bits in ATmega
*           uint32_t     : 32bits in ATmega
*/




ISR(USART0_RX_vect)
{
	uint8_t rcv_data;
	//LED_Toggle(LED0);

	while(!(UCSR0A & (1 << RXC0)));
	rcv_data = UDR0;

	//uart0_tx(rcv_data, NULL);
}




static void uart0_tx(char c, FILE *stream)
{
	if(c == '\n')
	{
		while((UCSR0A & (1 << UDRE0)) == 0);
		UDR0 = 0x0D;	// carriage return
	}

	while((UCSR0A & (1 << UDRE0)) == 0);
	UDR0 = c;
}




static void uart0_rx(FILE *stream)
{
	char data;

	while (!(UCSR0A & (1 << RXC0)));

	data = UDR0;
	//uart0_tx(data, stream);	// verify by echo...
}



static void uart_rx_intr_enable(void)
{
	UCSR0B |= (1 << RXCIE0);
}



void DRV_USART0_Printf_Init(uint32_t baudrate)
{
	float f_value;
	uint32_t ubr_reg;

	sysclk_enable_peripheral_clock(&UCSR0A);

	/* Set baud rate */
	/* Caution : Expression FOSC / ( 16 * baudrate) - 1 may cause data crack. */

	//f_value = ((float)(FOSC / 16.) / baudrate - 1);
	f_value = ((float)FOSC / (16. * baudrate) - 1.);

	ubr_reg = (uint32_t)f_value;
	if(f_value - ubr_reg > 0.5)
		ubr_reg++;

	UCSR0A = 0;
	UCSR0B = 0;

	/* Set frame format: 8data, 1stop bit */
	UCSR0C = (0 << UMSEL0) | (0 << USBS0) | (3 << UCSZ00);

	UBRR0H = (unsigned char)((ubr_reg >> 8) & 0xFF);
	UBRR0L = (unsigned char)(ubr_reg & 0xFF);

	/* Enable receiver and transmitter #1. */
	UCSR0B = (1 << RXEN0) | (1 << TXEN0);

	/* Activate RX Complete Interrupt Enable #1. */
	/* NOTICE : When you use ANSI-C input such as gets() or scanf(), do not configure RX interrupt. */
	//UCSR0B |= (1 << RXCIE0);		// = uart_rx_intr_enable();

	// Assign device(mystdio) to stdout & stdin.
	stdout = stdin = &mystdio;

	//_delay_ms(10);
}




#if 0
void DRV_USART0_Init(uint32_t baudrate)
{
	float f_value;
	uint32_t ubr_reg;

	sysclk_enable_peripheral_clock(&UCSR0A);

	/* Set baud rate */
	/* Caution : Expression FOSC / ( 16 * baudrate) - 1 may cause data crack. */

	//f_value = ((float)(FOSC / 16.) / baudrate - 1);
	f_value = ((float)FOSC / (16. * baudrate) - 1.);

	ubr_reg = (uint32_t)f_value;
	if(f_value - ubr_reg > 0.5)
		ubr_reg++;

	UCSR0A = 0;
	UCSR0B = 0;

	/* Set frame format: 8data, 1stop bit */
	UCSR0C = (0 << UMSEL0) | (0 << USBS0) | (3 << UCSZ00);

	UBRR0H = (unsigned char)((ubr_reg >> 8) & 0xFF);
	UBRR0L = (unsigned char)(ubr_reg & 0xFF);

	/* Enable receiver and transmitter #1. */
	UCSR0B = (1 << RXEN0) | (1 << TXEN0);

	/* Activate RX Complete Interrupt Enable. */
	UCSR0B |= (1 << RXCIE0);		// = uart_rx_intr_enable();

	//_delay_ms(10);
}
#endif

/* End of File */
