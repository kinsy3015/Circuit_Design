#include <asf.h>
#include <stdio.h>
#include <util/delay.h>

#include "drv_spi.h"
#include "drv_sst25pf040c.h"

#define SPI_SS							IOPORT_CREATE_PIN(PORTE, 2)




uint32_t DRV_SFlash_ReadID(uint8_t *pid)
{
	volatile uint8_t command[4] = {0x0, 0x0, 0x0, 0x0};
	uint32_t error_code;


	DRV_SPI_CtrlSS(0);

	command[0] = SST25PF040_CMD_READID;
	error_code = DRV_SPI_Send(command, 4);

	if(error_code)
	{
		printf("A\r\n");
		goto _readid_exit_;
	}

	error_code = DRV_SPI_Recv(command, 4);

	if(error_code)
	{
		printf("B\r\n");
		goto _readid_exit_;
	}

_readid_exit_:
	DRV_SPI_CtrlSS(1);

	*pid = command[0];
	//printf("*pid = 0x%X\r\n", *pid);


	return error_code;
}



uint32_t DRV_SFlash_Read_JEDECID(uint8_t *pid)
{
	volatile uint8_t command[4] = {0x0, 0x0, 0x0, 0x0};
	uint32_t error_code;


	DRV_SPI_CtrlSS(0);

	command[0] = SST25PF040_CMD_READ_JEDECID;
	error_code = DRV_SPI_Send(command, 1);

	if(error_code)
	goto _readid_exit_;

	error_code = DRV_SPI_Recv(command, 4);

	if(error_code)
	goto _readid_exit_;

_readid_exit_:
	DRV_SPI_CtrlSS(1);

	pid[0] = command[0];
	pid[1] = command[1];
	pid[2] = command[2];
	pid[3] = command[3];


	return error_code;
}




uint32_t DRV_SFlash_Write(uint32_t start_addr, uint8_t *pbuf, uint32_t size)
{
	volatile uint8_t command[4] = {0x0, };
	uint32_t error_code;


	/* Write Enable */
	DRV_SPI_CtrlSS(0);

	command[0] = SST25PF040_CMD_WREN;
	error_code = DRV_SPI_Send(&command[0], 1);

	if(error_code)
		goto _write_exit_;

	DRV_SPI_CtrlSS(1);

	/* Write */
	command[0] = SST25PF040_CMD_PAGEPGM;
	command[1] = (start_addr >> 16) & 0xFF;
	command[2] = (start_addr >> 8) & 0xFF;
	command[3] = start_addr & 0xFF;

	DRV_SPI_CtrlSS(0);
	error_code |= DRV_SPI_Send(command, 4);

	if(error_code)
		goto _write_exit_;

	error_code |= DRV_SPI_Send(pbuf, size);

	if(error_code)
		goto _write_exit_;

	DRV_SPI_CtrlSS(1);

	DRV_SPI_CtrlSS(0);

	while(1)
	{
		command[0] = SST25PF040_CMD_READRDSR;

		error_code |= DRV_SPI_Send(&command[0], 1);

		command[0] = 0;
		error_code |= DRV_SPI_Recv(&command[0], 1);

		if(!(command[0] & 0x01))
		{
			break;
		}
	}

	DRV_SPI_CtrlSS(1);

#if 0
	/* Write Disable */
	DRV_SPI_CtrlSS(0);

	command[0] = SST25PF040_CMD_WRDI;
	error_code |= DRV_SPI_Send(&command[0], 1);
#endif

_write_exit_:
	DRV_SPI_CtrlSS(1);


	return error_code;
}



uint32_t DRV_SFlash_Read(uint32_t start_addr, uint8_t *pbuf, uint32_t size)
{
	volatile uint8_t command[4] = {0x0, };
	uint32_t error_code;

	/* Read flash */
	command[0] = SST25PF040_CMD_READ;
	command[1] = (start_addr >> 16) & 0xFF;
	command[2] = (start_addr >> 8) & 0xFF;
	command[3] = start_addr & 0xFF;

	DRV_SPI_CtrlSS(0);
	error_code = DRV_SPI_Send(command, 4);

	if(error_code)
		goto _write_exit_;

	error_code |= DRV_SPI_Recv(pbuf, size);

	if(error_code)
		goto _write_exit_;
	
_write_exit_:
	DRV_SPI_CtrlSS(1);


	return error_code;
}




uint32_t DRV_SFlash_EraseAddr(uint32_t start_addr, uint32_t end_addr)
{
	volatile uint8_t command[4] = {0x0, };
	uint32_t error_code;

	start_addr = (start_addr / SST25PF040_SECTOR_SIZEBYTE);
	start_addr *= SST25PF040_SECTOR_SIZEBYTE;

	end_addr = (end_addr / SST25PF040_SECTOR_SIZEBYTE);
	end_addr *= SST25PF040_SECTOR_SIZEBYTE;

	while(start_addr <= end_addr)
	{
		/* Write Enable */
		DRV_SPI_CtrlSS(0);

		command[0] = SST25PF040_CMD_WREN;
		error_code = DRV_SPI_Send(&command[0], 1);

		DRV_SPI_CtrlSS(1);

		command[0] = SST25PF040_CMD_ERASE_SECTOR;
		command[1] = (start_addr >> 16) & 0xFF;
		command[2] = (start_addr >> 8) & 0xFF;
		command[3] = start_addr & 0xFF;

		DRV_SPI_CtrlSS(0);
		error_code |= DRV_SPI_Send(command, 4);
		DRV_SPI_CtrlSS(1);

		DRV_SPI_CtrlSS(0);

		while(1)
		{
			command[0] = SST25PF040_CMD_READRDSR;

			error_code |= DRV_SPI_Send(&command[0], 1);

			command[0] = 0;
			error_code |= DRV_SPI_Recv(&command[0], 1);

			if(!(command[0] & 0x01))
			{
				break;
			}
		}

		DRV_SPI_CtrlSS(1);

		start_addr += SST25PF040_SECTOR_SIZEBYTE;
	}


	return error_code;
}

/* End of File */
