#ifndef __ATMEGA128A_USART0_CONSOLE_HEADER__
#define __ATMEGA128A_USART0_CONSOLE_HEADER__

extern void DRV_USART0_Printf_Init(uint32_t);
//extern void DRV_USART0_Init(uint32_t);

#endif		/* End of __ATMEGA128A_USART0_CONSOLE_HEADER__ */
