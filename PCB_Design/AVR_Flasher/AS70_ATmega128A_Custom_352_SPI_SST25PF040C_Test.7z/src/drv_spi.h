#ifndef __ATMEGA128A_SPI_INCLUDE_HEADER__
#define __ATMEGA128A_SPI_INCLUDE_HEADER__

#include <asf.h>

#define PORT_SPI_SS						(*(PORT_t *)0x36)
#define PIN_SPI_SS						(1 << 0)

#define UNUSED(v)						(void)(v)


extern void DRV_SPI_Init(uint8_t flag);

extern void DRV_SPI_CtrlSS(uint8_t flag);
extern uint32_t DRV_SPI_Send(uint8_t *pbuf, uint32_t size);
extern uint32_t DRV_SPI_Recv(uint8_t *pbuf, uint32_t size);
extern uint32_t DRV_SPI_Transceive(uint8_t *ptxbuf, uint32_t tx_size, uint8_t *prxbuf, uint32_t rx_size);

#endif	// End of __ATMEGA128A_SPI_INCLUDE_HEADER__
