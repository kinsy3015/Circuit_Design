#include <stdio.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "drv_spi.h"
#include "drv_sst25pf040c.h"
#include "drv_usart0_console.h"




int main(void)
{
	uint8_t data[512];

	uint8_t master_flag = 1;
	uint8_t id[4];
	uint32_t error_code;


	sysclk_init();
	board_init();

	/* Initialize USART for STDIO */
	DRV_USART0_Printf_Init(115200);

	printf("ATmega128A SPI Test -- SST25PF040C Serial Flash Test\r\n\n");

	DRV_SPI_Init(master_flag);
	DRV_SPI_CtrlSS(1);

	printf("[Read ID] : ");
	if((error_code = DRV_SFlash_ReadID(&id[0])) != 0)
	{
		printf("Error Status 0x%X\r\n", error_code);
		while(1);
	}

	if(id[0] != SST25PF040_ID)
	{
		printf("Error SST25PF040C ID not matched => 0x%X (0x6E)\r\n", id[0]);
		while(1);
	}

	printf("ID = 0x%X\r\n", id[0]);

	printf("[Read JEDEC ID] : ");
	if((error_code = DRV_SFlash_Read_JEDECID(id)) != 0)
	{
		printf("Error Status 0x%X\r\n", error_code);
		while(1);
	}
	printf("0x%X 0x%X 0x%X 0x%X\r\n\n", id[0], id[1], id[2], id[3]);

	printf("[Erase]... ");
	if((error_code = DRV_SFlash_EraseAddr(0x00, SST25PF040_SECTOR_SIZEBYTE - 1)) != 0)
	{
		printf("Error Status 0x%X\r\n", error_code);
		while(1);
	}
	printf("Done\r\n");

	/* Generate test data pattern */
	for(volatile uint16_t count = 0; count < 512; count++)
	{
		data[count] = count % 256;
	}

	/* The Page-Program instruction programs up to 256 Bytes of data in the memory. */
	printf("[Write] Address 0x00 ~ 0xFF... ");
	if((error_code = DRV_SFlash_Write(0x00, data, 256)) != 0)
	{
		printf("Error Status 0x%X\r\n", error_code);
		while(1);
	}
	printf("Done\r\n");

	printf("[Write] Address 0x100 ~ 0x1FF... ");
	if((error_code = DRV_SFlash_Write(256, (data + 256), 256)) != 0)
	{
		printf("Error Status 0x%X\r\n", error_code);
		while(1);
	}
	printf("Done\r\n");

	printf("[Read] Address area = 0x00 ~ 0x1FF... ");
	if((error_code = DRV_SFlash_Read(0x00, data, 512)) != 0)
	{
		printf("Error Status 0x%X\r\n", error_code);
		while(1);
	}
	printf("Done\r\n\n");

	printf("[Data Display] Address 0x00 ~ 0x1FF\r\n\n");
	for(uint16_t count = 0; count < 512; count++)
	{
		printf("%02X ", data[count]);

		if((count % 16) == 15)
			printf("\r\n");
	}

	printf("\nTest done.\r\n");

	while (1)
	{
		PORTG = ~PORTG & 0x03;
		_delay_ms(500);
	}
}

